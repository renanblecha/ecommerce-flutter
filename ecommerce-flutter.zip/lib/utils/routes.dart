class Routes {
  static final String HOME = "/home";
  static final String LOGIN = "/login";
  static final String REGISTER = "/register";
  static final String PRODUCT = "/product";
  static final String CART = "/cart";
  static final String ADDRESS = "/address";
}
